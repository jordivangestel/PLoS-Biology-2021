// SEPARATE HEADER FILE FOR TYPE 1 REGULATION
#ifndef DP_H1
	#define DP_H1

// BOOST RANDOM NUMBER GENERATOR /////////////////////////////////////////////////////////////////
typedef boost::mt11213b rndeng;
rndeng rndgen;                      //< The one and only random number generator

int rn(int n)
{
	if(n==1) return 0; //quick escape
	return boost::uniform_int<int>(0,n-1)(rndgen);
}
double ru(){return boost::uniform_01<double>()(rndgen);}
double norm(double sd){return boost::normal_distribution<double>(0,sd)(rndgen);}
void set_seed(unsigned seed){rndgen.seed(rndeng::result_type(seed));}
// BOOST RANDOM NUMBER GENERATOR /////////////////////////////////////////////////////////////////

void mu(double &Value)
{
	double V = Value;
	double mu_size = norm(u_size);
	mu_size -= fmod(mu_size,0.001);
	V += mu_size;
	Value = V;
	return;
}

void constraint(double &Value, double Low, double High)
{
	double V = Value;
	if(V < Low)		V = Low;
	if(V > High)	V = High;
	Value = V;
	return;
}

struct DP
{
	// GENOTYPE
	int		Gt;						// Genotype ID
	int		pGt;					// Previous genotype ID
	double 	P_T;					// Probability of differentiation
	
	// PHENOTYPE
	bool	T;						// Phenotype (0=non-adhesive;1=adhesive)
	
	//  FUNCTIONS
	void InitDP();
	void DevelopDP(double,double);	// Differentiation probability
	void MutateDP();
};

// Init
void DP::InitDP()
{
	T		= 0;
	Gt		= 0;
	pGt		= 0;
	P_T		= 0;
}

void DP::DevelopDP(double input1, double input2)
{
	ru() < P_T? T = 1 : T = 0;
	return;
}

void DP::MutateDP()
{

	bool Mut = 0;
	
	double P_Tb = P_T;
	if(ru() < u_rate){mu(P_T);}
	constraint(P_T,0,1);
	if(P_Tb != P_T)  {Mut = 1;}
	
	// ADMINISTRATION; keep track of genotype number
	if(Mut)
	{
		pGt = Gt;
		Gt  = Gcount + 1;
		Gcount += 1;
	}
	
	return;
}
#endif
