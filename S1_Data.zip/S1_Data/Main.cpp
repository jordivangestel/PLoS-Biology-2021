// Publication: Cell adhesion and its regulatory control can drive the emergence of cryptic surface-associated multicellularity
// Author: Jordi van Gestel
// April 2021

// Packages
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cmath>
#include <cassert>
#include <sstream>
#include <boost/random.hpp>
using namespace std;

/////////////////////////
//  GLOBAL PARAMETERS  //
/////////////////////////
const int	 iSeed		= 1;		// Random Seed
const int	 T_max		= 200000;	// Maximal duration of simulation
const int	 n_env		= 0;		// By default cells are in bulk, but one could also initiate some cells on grid in the beginning of simulations.

// Relative rates at which events occur in the model (this is to mimick continuous chemical systems)
const int	 nE			= 5;		// Number of events
const double P_att		= 0.1;		// Probability of attachment
const double P_det		= 1.0; 	 	// Probability of dettachment
const double P_dea		= 0.1;		// Probability of cell death
const double P_dif		= 1.0; 		// Probability of cell differentiation

// Relative cell division rates
const double cBL		= 1.0;		// Baseline cell division rate
const double cAB		= 0.4;		// Reduced cell division rate for being adhesive

// Dimensions
const int	 K_bulk		= 5000;		// Carrying capacity of bulk population
const int	 K_grid		= 100;		// Size (length and width) of grid

// Evolution
const double u_rate		= 0.05;	// Mutation rate
const double u_size		= 0.1;		// Mutation size

int	 Gcount = 1;					// Counts number of genotype
int	 Mcount = 1;					// Count number of collectives
int	 Ccount = 1;					// Count number of cells
#include "Type 1.h"					// Header file determining type of regulation

//////////////////
//  STRUCTURES  //
//////////////////
struct Cell
{
	bool	O;			// Note if cell exists
	bool	N;			// Niche: (0) Bulk (1) Grid
	bool	pN;			// Previous niche: (0) Bulk (1) Grid
	int		a;			// Age of the cell
	int		x;			// Position on the grid (x)
	int		y;			// Position on the grid (y)
	DP		G;			// Genotype (depending on header file)

	int		cID;		// Current cell ID
	int		pID;		// Previous cell ID
	bool	D;			// Note if cell died
	
	int		Mt;			// For tracking purposes, current ID of collective
	int		pMt;		// For tracking purposes, past ID of collective 
	int		Ct;			// For tracking purposes, currend ID of cell
	int		pCt;		// For tracking purposes, past ID of cell
	
	void InitCell();	// Initiate cell
	double Division();	// Determine probability of cell division
};

void Cell::InitCell()
{
	// CELLULAR PROPERTIES
	O		= 0;
	N		= 0;
	pN		= 0;
	a		= 0;
	x		= 0;
	y		= 0;
	
	// ADMINSTRATION PROPERTIES
	cID		= 0;
	pID		= 0;
	D		= 0;

	// TRACKING INFORMATION
	Mt		= 0;
	pMt		= 0;
	Ct		= 0;
	pCt		= 0;

	DP Empty;
	Empty.InitDP();
	G = Empty;
}

struct Grid
{
	// Variables
	vector<vector<bool>	>	C;							// Boolean determining whether grid element is occupied by cell
	vector<vector<int> >	IDs;						// ID information of cells on grid

	void GetN1(vector<int> &,vector<int> &, int, int);	// Obtain neighboring grid elements
	void PrintGrid(int);								// Print grid information
	void InitGrid();									// Initiate surface
};

void Grid::InitGrid()
{
	vector<bool>	bRow;
	vector<int>	    iRow;
	bRow.assign(K_grid,0);
	iRow.assign(K_grid,0);

	C.assign(K_grid,bRow);
	IDs.assign(K_grid,iRow);
}

///////////////////////////////
//  GLOBAL TRACKING VECTORS  //
///////////////////////////////
Cell EmptyCell;		// To get adress for all empty cells.
Cell *Empty;		// Gives address of all empty cell; just a construct that is used for output text-file

vector<Cell*> AD;	// List of addresses of all individiduals; sorted on ID (fixed ordering)
vector<Cell*> ADn;	// List of new addresses generated during cell division (fixed ordering)
vector<int>   ID;	// This vector is used to shuffle calling cells
int ID_bulk;		// Cells in bulk
int ID_grid;		// Cells on grid
vector<Cell>  CL;	// List of cells Cell (fixed ordering)
Grid GN;			// Grid (hexogonal surface)

///////////////
// FUNCTIONS //
///////////////
double Cell::Division()
// DETERMINE DIVISION PROBABILITY
{
	double D_temp = cBL; 		// Probability of cell division
	if(G.T == 1) D_temp *= cAB; // Reduced probability due to expressing adhesion
	return D_temp;
}

void Grid::GetN1(vector<int> &gNx, vector<int> &gNy, int gxi, int gyi)
// GET NEIGHBORING GRID ELEMENTS
{
	gNx.clear();
	gNy.clear();
	int inits_x[]={gxi-1,gxi+1,gxi,gxi};
	int inits_y[]={gyi,gyi,gyi+1,gyi-1};
	vector<int> gNx_temp(inits_x,inits_x+4);
	vector<int> gNy_temp(inits_y,inits_y+4);
		
	if(gyi%2==0)
	{
		gNx_temp.push_back(gxi+1);
		gNx_temp.push_back(gxi+1);
		gNy_temp.push_back(gyi+1);
		gNy_temp.push_back(gyi-1);
	}
	if(gyi%2==1)
	{
		gNx_temp.push_back(gxi-1);
		gNx_temp.push_back(gxi-1);
		gNy_temp.push_back(gyi+1);
		gNy_temp.push_back(gyi-1);
	}
	assert(gNx_temp.size() == 6 && gNy_temp.size() == 6);
	assert(K_grid > 1);

	// REMOVE GRID ELEMENTS THAT FALL OUTSIDE GRID BOUNDARIES (NO CONTINUOUS IMPLEMENTATINO OF THE SURFACE)
	vector<int>::iterator Ix = gNx_temp.begin();
	vector<int>::iterator Iy = gNy_temp.begin();
	while(Ix != gNx_temp.end())
	{
		if(*Ix < 0 || *Ix >= K_grid || *Iy < 0 || *Iy >= K_grid)
		{

			Ix = gNx_temp.erase(Ix);
			Iy = gNy_temp.erase(Iy);
		}
		else
		{
			++Ix;
			++Iy;
		}
	}
	
	gNx = gNx_temp;
	gNy = gNy_temp;
	gNx_temp.clear();
	gNy_temp.clear();
	
	assert(gNx.size() == gNy.size());
	assert(gNx.size() > 0);
	assert(gNx.size() <= 6);
}

void RV(vector<int> &R, int sizev)
// RANDOMIZE VECTOR
{
	vector<int> RN;
	for(int i = 0; i < sizev; ++i) RN.push_back(R[i]);
	random_shuffle(RN.begin(),RN.end());
	R.clear();
	R = RN;
}

void UpdateAtt(int i)
// CELL ATTACHMENT
{
	assert(AD[i]->O == 1);
	if(ru() < P_att && AD[i]->N == 0) 
	// Attach when (i) probability of attachment and (ii) cell is in bulk
	{
		int rx, ry;
		rx = rn(K_grid);
		ry = rn(K_grid);
		if(GN.C[rx][ry]==0) // If there is space available
		{
			bool immi = 0;
			if(AD[i]->G.T == 1) immi = 1;	// If cell is adhesive
			if(AD[i]->G.T == 0) 			// if cell has adhesive neighbor on grid
			{
				vector<int> xl, yl;
				GN.GetN1(xl,yl,rx,ry);	// Get all neighboring cells
				for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].G.T == 1) immi = 1;
			}
			if(immi) // When adhesion criteria is met
			{
				GN.C[rx][ry]	= 1;
				GN.IDs[rx][ry]	= AD[i]->cID;
				
				AD[i]->x		= rx;
				AD[i]->y		= ry;
				AD[i]->N		= 1;
				
				ID_bulk -= 1;
				ID_grid += 1;
			}
		}
	}
	return;
}

void UpdateDif(int i)
// CELL DIFFERENTIATION (EXPRESSION OF ADHESION OR NOT)
{
	assert(AD[i]->O == 1);
	
	double Input1 = 0;
	double Input2 = 0;
	int G_self = AD[i]->G.Gt;
	if(AD[i]->N == 0) // BULK
	{
		int cT, cC, cO;
		cT = cC = cO = 0;
		for(int iC = 0; iC < AD.size(); ++iC) 
		{
			if(AD[iC]->N == 0) {cT += int(AD[iC]->G.T); ++cC;}
			if(AD[iC]->G.Gt == G_self) {++cO;}
		}
		if(cC > 0) Input1 = double(cT)/K_bulk; // Fraction of adhesive cells in bulk
		if(cC > 0) Input2 = double(cO)/K_bulk; // Fraction of cells with same genotype in bulk
	}
	else // GRID
	{
		int xn, yn, cT, cC, cO;
		cT = cC = cO = 0;
		vector<int> xl, yl;
		xn = AD[i]->x;
		yn = AD[i]->y;
		
		GN.GetN1(xl,yl,xn,yn);
		for(int iN = 0; iN < xl.size(); ++iN) 
		{
			if(GN.C[xl[iN]][yl[iN]])
			{
				++cC;
				if(CL[GN.IDs[xl[iN]][yl[iN]]].G.T == 1) ++cT;
				if(CL[GN.IDs[xl[iN]][yl[iN]]].G.Gt == G_self) ++cO;
			}
		}
		if(cC > 0) Input1 = double(cT)/6; // Fraction of neighbors expressing adhesion
		if(cC > 0) Input2 = double(cO)/6; // Fraction of neighbors with same genotype
	}
	AD[i]->G.DevelopDP(Input1,Input2);
	return;
}

void UpdateDet(int i)
// CELL DETACHMENT
{
	assert(AD[i]->O == 1);
	if(ru() < P_det && AD[i]->N == 1 && AD[i]->G.T == 0) 
	// Dettachment if (i) probability of detachment, (ii) when cell is on grid and (iii) when cell is not adhesive (check below if neighbors are not adhesive either)
	{
		int xn, yn;
		vector<int> xl, yl;
		xn = AD[i]->x;
		yn = AD[i]->y;
		
		GN.GetN1(xl,yl,xn,yn);
		bool StiCel = 0;
		for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].G.T == 1) StiCel = 1;
		if(!StiCel)	// When neighbors are not adhesive either detach
		{
			GN.C[xn][yn]   = 0;
			GN.IDs[xn][yn] = 0;
			
			AD[i]->x = 0;
			AD[i]->y = 0;
			AD[i]->N = 0;
			
			ID_bulk += 1;
			ID_grid -= 1;
			
			// DETERMINE IF DETACHMENT RESULTS IN COLLECTIVE REPRODUCTION
			int M_ID = AD[i]->Mt;	// Collective ID
			vector<int> M_init;		// Determine neighbors with same ID
			for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_init.push_back(GN.IDs[xl[iN]][yl[iN]]);
			if(M_init.size() != 0)	// Check if there are neigbhors with same ID, otherwise there is no reproduction event
			{
				AD[i]->pMt = AD[i]->Mt;		// Update prevous collective ID
				AD[i]->Mt  = Mcount;		// Update current collective ID
				Mcount += 1;				// Track number of collective IDs
				
				// Check if neighbors are still connected
				vector<int> M_sub;
				for(int iM = 0; iM < M_init.size(); ++iM)
				{
					xl.clear(), yl.clear();
					xn = CL[M_init[iM]].x;
					yn = CL[M_init[iM]].y;
					
					GN.GetN1(xl,yl,xn,yn);	 // Get all neighboring cells
					for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_sub.push_back(GN.IDs[xl[iN]][yl[iN]]);
				}
				
				bool M_connected = 1;
				for(int iM = 0; iM < M_init.size(); ++iM)
				{
					bool M_check = 0;
					for(int iN = 0; iN < M_sub.size(); ++iN) if(M_sub[iN] == M_init[iM]) M_check = 1;
					if(!M_check) M_connected = 0;
				}
				
				// DETERMINE THE OCCURRANCE OF FRAGMENTATION
				if(!M_connected || M_init.size() == 4)
				{
					vector<int> M_group;
					for(int iN = 0; iN < CL.size(); ++iN) if(CL[iN].O == 1 && CL[iN].N == 1 && CL[iN].Mt == M_ID) M_group.push_back(CL[iN].cID);
					vector<int> M_score;
					M_score.assign(M_group.size(),0);
					int		M_count		= 1;
					bool	M_scoring	= 1;
					M_score[0]			= M_count;
					
					while(M_scoring)
					{
						bool new_score = 0;
						for(int iM1 = 0; iM1 < M_score.size(); ++iM1) 
						{	
							if(M_score[iM1] == M_count)
							{
								xl.clear(), yl.clear(); M_sub.clear();
								xn = CL[M_group[iM1]].x;
								yn = CL[M_group[iM1]].y;
									
								GN.GetN1(xl,yl,xn,yn);
								for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_sub.push_back(GN.IDs[xl[iN]][yl[iN]]);
								if(M_sub.size() > 0) for(int iM2 = 0; iM2 < M_group.size(); ++iM2) if(M_score[iM2] == 0)
								{
									for(int iN2 = 0; iN2 < M_sub.size(); ++iN2) if(M_sub[iN2] == M_group[iM2]) {M_score[iM2] = M_count; new_score = 1;}
								}
							}
						}
						
						if(new_score == 0)
						{
							bool M_check = 0;
							for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 0) M_check = 1;
							
							if(M_check)
							{
								bool M_first = 0;
								for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 0 && M_first == 0) {M_count += 1; M_score[iM] = M_count; M_first = 1;}
							}
							
							if(!M_check)
							{
								if(M_count > 1)
								{
									vector<int> M_largest;
									M_largest.push_back(1);
									int M_old = 0;
									for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 1) M_old += 1;
									
									for(int iN = 1; iN < (M_count + 1); ++iN)
									{
										int M_new = 0;
										if(iN > 1)  
										{
											for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == iN) M_new += 1;
											if(M_new > M_old) {M_old = M_new; M_largest.clear(); M_largest.push_back(iN);}
											if(M_new == M_old){M_largest.push_back(iN);}
										}
									}
									RV(M_largest,M_largest.size());
									int M_constant = M_largest[0];
									for(int iN = 1; iN < (M_count + 1); ++iN) if(iN != M_constant)
									{
										for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == iN)
										{
											CL[M_group[iM]].pMt = CL[M_group[iM]].Mt;	// Update previous ID collective
											CL[M_group[iM]].Mt  = Mcount;				// Update current ID collective
										}
										Mcount += 1;
									}
								}
								M_scoring = 0;
							}
						}
					}
				}
			}
		}
	}
	return;
}

void UpdateDea(int i)
// CELL DEATH
{
	assert(AD[i]->O == 1);
	if(ru() < P_dea)
	{
		int p = AD[i]->cID; 
		ID.push_back(p);
		CL[p].O = 0;
		CL[p].D = 1;
		CL[p].N == 0? ID_bulk -= 1:ID_grid -= 1;
		if(CL[p].N == 1)
		{
			GN.C[CL[p].x][CL[p].y]	 = 0;
			GN.IDs[CL[p].x][CL[p].y] = 0;
			
			// DETERMINE IF CELL DEATH RESULTS IN FRAGMENTATION
			int M_ID = CL[p].Mt;
			vector<int> M_init;
			int xn, yn;
			vector<int> xl, yl;
			xn = CL[p].x;
			yn = CL[p].y;
			GN.GetN1(xl,yl,xn,yn);
			for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_init.push_back(GN.IDs[xl[iN]][yl[iN]]);
			if(M_init.size() != 0)
			{
				vector<int> M_sub;
				for(int iM = 0; iM < M_init.size(); ++iM)
				{
					xl.clear(), yl.clear();
					xn = CL[M_init[iM]].x;
					yn = CL[M_init[iM]].y;
					
					GN.GetN1(xl,yl,xn,yn);
					for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_sub.push_back(GN.IDs[xl[iN]][yl[iN]]);
				}
				
				bool M_connected = 1;
				for(int iM = 0; iM < M_init.size(); ++iM)
				{
					bool M_check = 0;
					for(int iN = 0; iN < M_sub.size(); ++iN) if(M_sub[iN] == M_init[iM]) M_check = 1;
					if(!M_check) M_connected = 0;
				}
				
				// DETERMINE THE OCCURRANCE OF FRAGMENTATION
				if(!M_connected || M_init.size() == 4)
				{
					vector<int> M_group;
					for(int iN = 0; iN < CL.size(); ++iN) if(CL[iN].O == 1 && CL[iN].N == 1 && CL[iN].Mt == M_ID) M_group.push_back(CL[iN].cID);
					vector<int> M_score;
					M_score.assign(M_group.size(),0);
					int		M_count		= 1;
					bool	M_scoring	= 1;
					M_score[0]			= M_count;
					
					while(M_scoring)
					{
						bool new_score = 0;
						for(int iM1 = 0; iM1 < M_score.size(); ++iM1) 
						{	
							if(M_score[iM1] == M_count)
							{
								xl.clear(), yl.clear(); M_sub.clear();
								xn = CL[M_group[iM1]].x;
								yn = CL[M_group[iM1]].y;
									
								GN.GetN1(xl,yl,xn,yn);
								for(int iN = 0; iN < xl.size(); ++iN) if(GN.C[xl[iN]][yl[iN]]) if(CL[GN.IDs[xl[iN]][yl[iN]]].Mt == M_ID) M_sub.push_back(GN.IDs[xl[iN]][yl[iN]]);
								if(M_sub.size() > 0) for(int iM2 = 0; iM2 < M_group.size(); ++iM2) if(M_score[iM2] == 0)
								{
									for(int iN2 = 0; iN2 < M_sub.size(); ++iN2) if(M_sub[iN2] == M_group[iM2]) {M_score[iM2] = M_count; new_score = 1;}
								}
							}
						}
						
						if(new_score == 0)
						{
							bool M_check = 0;
							for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 0) M_check = 1;
							if(M_check)
							{
								bool M_first = 0;
								for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 0 && M_first == 0) {M_count += 1; M_score[iM] = M_count; M_first = 1;}	
							}
							
							if(!M_check)
							{
								if(M_count > 1)
								{
									vector<int> M_largest; 
									M_largest.push_back(1);
									int M_old	  = 0;
									for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == 1) M_old += 1;
									
									for(int iN = 1; iN < (M_count + 1); ++iN)
									{
										int M_new = 0;
										if(iN > 1)
										{
											for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == iN) M_new += 1;
											if(M_new > M_old) {M_old = M_new; M_largest.clear(); M_largest.push_back(iN);}
											if(M_new == M_old){M_largest.push_back(iN);}
										}
									}
									RV(M_largest,M_largest.size());
									int M_constant = M_largest[0];
									for(int iN = 1; iN < (M_count + 1); ++iN) if(iN != M_constant)
									{
										for(int iM = 0; iM < M_score.size(); ++iM) if(M_score[iM] == iN)
										{
											CL[M_group[iM]].pMt = CL[M_group[iM]].Mt;	// Update previous ID collective
											CL[M_group[iM]].Mt  = Mcount;				// Update current ID collective
										}
										Mcount += 1;
									}
								}
								M_scoring = 0;
							}
						}
					}
				}
			}
		}
	}
	return;
}

void UpdateCel(int i)
// CELL DIVISION
{
	assert(AD[i]->O == 1);
	double P_cel = AD[i]->Division();
	if(ru() < P_cel)
	{
		if(AD[i]->N == 0) // BULK
		{
			if(ID_bulk < K_bulk)
			{
				Cell Copy = *AD[i];
				int I = *(ID.end() - 1);
				assert(CL[I].O == 0);
				ID.pop_back();
				bool D_temp = CL[I].D;
				CL[I] = Copy;
				CL[I].D = D_temp;
				CL[I].a = 0;
				CL[I].G.MutateDP();
				
				// UPDATE TRACKING INFORMATION
				CL[I].pCt = CL[I].Ct;
				CL[I].Ct  = Ccount;
				CL[I].pMt = CL[I].Mt;
				CL[I].Mt  = Mcount;
				Ccount += 1;
				Mcount += 1;
				
				//ADMINSTRATION
				CL[I].cID = I;			// (A1) New ID
				CL[I].pID = AD[i]->cID; // (A2) ID of previous cell
				
				ID_bulk += 1;
				ADn.push_back(&CL[I]);
			}
		}
		
		if(AD[i]->N == 1) // GRID
		{
			int xn, yn, nu, xn2, yn2;
			vector<int> xl, yl;
			xn = AD[i]->x;
			yn = AD[i]->y;
			
			GN.GetN1(xl,yl,xn,yn);
			vector<int>::iterator Ixl = xl.begin();
			vector<int>::iterator Iyl = yl.begin();
			while(Ixl != xl.end())
			{
				if(GN.C[*Ixl][*Iyl] == 1)
				{
					Ixl  = xl.erase(Ixl);
					Iyl  = yl.erase(Iyl);
				}
				else
				{
					++Ixl;
					++Iyl;
				}
			}
			assert(xl.size() <= 6);
			
			
			if(AD[i]->G.T == 0) // WHEN CELL IS NON-ADHESIVE ONLY KEEP NEIGHBOR POSITIONS THAT HAVE ADHESIVE NEIGHBOR
			{
				vector<int>::iterator Ixl = xl.begin();			
				vector<int>::iterator Iyl = yl.begin();
				while(Ixl != xl.end())
				{
					bool StiCel = 0;
					vector<int> xl2, yl2;
					GN.GetN1(xl2,yl2,*Ixl,*Iyl);	
					for(int iN = 0; iN < xl2.size(); ++iN) if(GN.C[xl2[iN]][yl2[iN]]) if(CL[GN.IDs[xl2[iN]][yl2[iN]]].G.T == 1) StiCel = 1;
					xl2.clear();
					yl2.clear();
					if(!StiCel)
					{
					
						Ixl  = xl.erase(Ixl);
						Iyl  = yl.erase(Iyl);
					}
					else
					{
						++Ixl;
						++Iyl;
					}
				}
			}
			
			// CALCULATE CHANCES OF CELL DIVISION ON GRID OR IN BULK
			bool cG = 0;
			bool cB = 0;
			if(ID_bulk < K_bulk) cB = 1;
			if(xl.size() > 0)	 cG = 1;
			if(cB && cG) rn(xl.size()+1) != 0? cB = 0: cG = 0;
			if(cG) // CELL DIVIDES TO GRID
			{
				nu = rn(xl.size());
				xn2 = xl[nu];
				yn2 = yl[nu];
				
				Cell Copy = *AD[i];
				int I = *(ID.end() - 1);
				assert(CL[I].O == 0);
				ID.pop_back();
				bool D_temp = CL[I].D;
				CL[I] = Copy;
				CL[I].D = D_temp;
				CL[I].a	= 0;
				CL[I].x	= xn2;
				CL[I].y	= yn2;
				CL[I].G.MutateDP();
				
				// UPDATE TRACKING INFORMATION
				CL[I].pCt = CL[I].Ct;
				CL[I].Ct  = Ccount;
				Ccount += 1;
				
				//ADMINSTRATION
				CL[I].cID = I;
				CL[I].pID = AD[i]->cID;
				
				ID_grid += 1;
				ADn.push_back(&CL[I]);
				GN.C[xn2][yn2] = 1;
				GN.IDs[xn2][yn2] = I;
			}
			
			if(cB) // CELL DIVIDES TO BULK
			{
				Cell Copy = *AD[i];
				int I = *(ID.end() - 1);
				assert(CL[I].O == 0); // Make sure that cell wasn't alive yet, when copying a dividing cell there
				ID.pop_back();
				bool D_temp = CL[I].D;
				CL[I] = Copy;
				CL[I].D = D_temp;
				CL[I].N	= 0;
				CL[I].a	= 0;
				CL[I].x	= 0;
				CL[I].y	= 0;
				CL[I].G.MutateDP();
				
				// UPDATE TRACKING INFORMATION
				CL[I].pCt = CL[I].Ct;
				CL[I].Ct  = Ccount;
				CL[I].pMt = CL[I].Mt;
				CL[I].Mt  = Mcount;
				Ccount += 1;
				Mcount += 1;
				
				// ADMINISTRATION
				CL[I].cID = I;
				CL[I].pID = AD[i]->cID;
				
				ID_bulk += 1;
				ADn.push_back(&CL[I]);
			}
		}
	}
	return;
}

int main()
{
	set_seed(iSeed);
	//////////////////
	//  INITIALIZE  //
	//////////////////
	// INITIALIZE GLOBAL (ADMINISTRATION) VECTORS
	GN.InitGrid();
	EmptyCell.InitCell();
	Empty = &EmptyCell;
	int CC = K_bulk+K_grid*K_grid;
	CL.assign(CC,EmptyCell);
	ID.assign(CC,0);
	ID_bulk = 0;
	ID_grid = 0;
	
	// ASSIGN IDs
	for(int iC = 0; iC < CC; ++iC) 
	{
		ID[iC] = iC;
		CL[iC].cID = iC;
		CL[iC].pID = iC;
	}
	
	// INITIALIZE POPULATION AT CARRYING CAPACITY
	for(int iC = 0; iC < K_bulk; ++iC)
	{
		int I = *(ID.end() - 1);
		ID.pop_back();
		CL[I].O	  = 1;
		CL[I].N	  = 0;
		CL[I].pN  = 0;
		CL[I].a	  = 0;
		CL[I].x	  = 0;
		CL[I].y	  = 0;
		// TRACKING INFORMATION
		CL[I].pCt = 0;
		CL[I].pMt = 0;
		CL[I].Ct  = Mcount;
		CL[I].Mt  = Ccount;
		Ccount += 1;
		Mcount += 1;
		AD.push_back(&CL[I]);
	}
	
	assert(K_grid*K_grid > n_env);
	// IF n_env > 0 INITIALIZE A PART OF THE POPULATION ON THE GRID
	ID_bulk = K_bulk;
	for(int iC = 0; iC < n_env; ++iC)
	{
		int rx, ry;
		rx = rn(K_grid);
		ry = rn(K_grid);
		if(GN.C[rx][ry]==0) // If there is space available
		{
			int I = *(ID.end() - 1);
			ID.pop_back();
			CL[I].O	 = 1;
			CL[I].N	 = 1;
			CL[I].pN = 1;
			CL[I].a	 = 0;
			CL[I].x	 = rx;
			CL[I].y	 = ry;
			// TRACKING INFORMATION
			CL[I].pCt = 0;
			CL[I].pMt = 0;
			CL[I].Ct  = Mcount;
			CL[I].Mt  = Ccount;
			Ccount += 1;
			Mcount += 1;
			
			GN.C[rx][ry]	= 1;
			GN.IDs[rx][ry]	= CL[I].cID;
			AD.push_back(&CL[I]);
			ID_grid += 1;
		}
	}
	
	//////////////////////
	//  CORE ALGORIGHM  //
	//////////////////////
	for(int iT = 0; iT < (T_max + 1); ++iT)
	{
		cout << "T: " << iT << "| B: " << ID_bulk  << "| G: " << ID_grid << endl;
		ADn.clear();
		vector<int> I;
		I.clear();
		I.assign(AD.size(),0);
		for(int iC = 0; iC < AD.size(); ++iC) I[iC] = iC;
		RV(I,I.size());
		for(int iC = 0; iC < AD.size(); ++iC)
		{
			int P = rn(nE);
			if(P == 0) UpdateAtt(I[iC]); // (1) Cell attachment
			if(P == 1) UpdateDif(I[iC]); // (2) Cell differentiation
			if(P == 2) UpdateDet(I[iC]); // (3) Cell dettachment
			if(P == 3) UpdateDea(I[iC]); // (4) Cell death 
			if(P == 4) UpdateCel(I[iC]); // (5) Cell division
		}
		
		// ADMINISTRATION: TAKE OUT DEATH CELLS
		vector<Cell*> ADcopy;
		for(int iC = 0; iC < AD.size(); ++iC) if(!AD[iC]->D) ADcopy.push_back(AD[iC]);
		AD.clear();
		for(int iC = 0; iC < ADcopy.size(); ++iC) AD.push_back(ADcopy[iC]);
		
		// ADMINISTRATION: ADD DAUGHTER CELLS
		for(int iC = 0; iC < AD.size();  ++iC) AD[iC] ->a += 1;			// Offsprings aren't included here, such that they have age 0
		for(int iC = 0; iC < ADn.size(); ++iC) ADn[iC]->D  = 0;			// Offsprings that occupied spot in vector that was occupied by recently died cell 
		for(int iC = 0; iC < ADn.size(); ++iC) AD.push_back(ADn[iC]);	// Add offspring to parent vector with addresses
		
		// CHECK CARRYING CAPACITY IN BULK
		ADcopy.clear();
		for(int iC = 0; iC < AD.size(); ++iC) if(!AD[iC]->D) ADcopy.push_back(AD[iC]);
		AD.clear();
		vector<int> IG;
		vector<int> IB;
		IG.clear();
		IB.clear();
		for(int iC = 0; iC < ADcopy.size(); ++iC)
		{
			if(ADcopy[iC]->N == 0) IB.push_back(iC);
			if(ADcopy[iC]->N == 1) IG.push_back(iC);
		}
		RV(IB,IB.size());
		assert(IB.size() == ID_bulk);
		assert(IG.size() == ID_grid);
		for(int iC = 0; iC < ID_grid; ++iC) AD.push_back(ADcopy[IG[iC]]);
		for(int iC = 0; iC < ID_bulk; ++iC)
		{
			if(iC <  K_bulk) AD.push_back(ADcopy[IB[iC]]);
			if(iC >= K_bulk) 
			{
				int p = ADcopy[IB[iC]]->cID;
				CL[p].O = 0;
				ID.push_back(p);
			}
		}
		if(ID_bulk > K_bulk) ID_bulk = K_bulk;
		
		// ASSERTMENT STATEMENTS
		assert(AD.size() == ID_grid + ID_bulk);
		assert(CC == ID_bulk + ID_grid + ID.size());
		assert(CC == ID.size() + AD.size());
		int countO0 = 0;
		int countO1 = 0;
		int countB	= 0;
		int countG  = 0;
		for(int iC = 0; iC < CL.size(); ++iC)
		{
			if(CL[iC].O == 0) ++countO0;
			if(CL[iC].O == 1) ++countO1;
			if(CL[iC].O == 1 && CL[iC].N == 0) ++countB;
			if(CL[iC].O == 1 && CL[iC].N == 1) ++countG;
		}
		assert(countB == ID_bulk);
		assert(countG == ID_grid);
		assert(countO0 == ID.size());
		assert(countO1 == AD.size());
		for(int iC = 0; iC < AD.size(); ++iC)
		{
			assert(AD[iC]->cID == CL[AD[iC]->cID].cID);
			if(AD[iC]->N == 1)
			{
				assert(GN.IDs[AD[iC]->x][AD[iC]->y] == AD[iC]->cID);
				assert(GN.C[AD[iC]->x][AD[iC]->y] == 1);
			}
		}
		countG  = 0;
		for(int ix = 0; ix < K_grid; ++ix)
		{
			for(int iy = 0; iy < K_grid; ++iy)
			{
				if(GN.C[ix][iy] == 0) assert(GN.IDs[ix][iy] == 0);
				if(GN.C[ix][iy] == 1) assert(CL[GN.IDs[ix][iy]].x == ix && CL[GN.IDs[ix][iy]].y == iy);
				if(GN.C[ix][iy] == 1) ++countG;
			}
		}
		assert(countG == ID_grid);
		
	}
	return 0;
}