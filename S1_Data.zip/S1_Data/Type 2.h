// SEPARATE HEADER FILE FOR TYPE 2 REGULATION
#ifndef DP_H1
	#define DP_H1

// BOOST RANDOM NUMBER GENERATOR /////////////////////////////////////////////////////////////////
typedef boost::mt11213b rndeng;
rndeng rndgen;                      //< The one and only random number generator

int rn(int n)
{
	if(n==1) return 0; //quick escape
	return boost::uniform_int<int>(0,n-1)(rndgen);
}
double ru(){return boost::uniform_01<double>()(rndgen);}
double norm(double sd){return boost::normal_distribution<double>(0,sd)(rndgen);}
void set_seed(unsigned seed){rndgen.seed(rndeng::result_type(seed));}
// BOOST RANDOM NUMBER GENERATOR /////////////////////////////////////////////////////////////////

void mu(double &Value)
{
	double V = Value;
	double mu_size = norm(u_size);
	mu_size -= fmod(mu_size,0.001);
	V += mu_size;
	Value = V;
	return;
}

void constraint(double &Value, double Low, double High)
{
	double V = Value;
	if(V < Low)		V = Low;
	if(V > High)	V = High;
	Value = V;
	return;
}

struct DP
{

	// GENOTYPE
	double 	P1;						// Minimal differentiation probability
	double 	P2;						// Maximum differentiation probability
	double 	P3;						// Inflection point
	double 	P4;						// Steepness
	int		Gt;						// Genotype ID
	int		pGt;					// Previous genotype ID
	
	// PHENOTYPE
	bool	T;						// Phenotype (0=non-adhesive;1=adhesive)
	
	// FUNCTIONS
	void InitDP();
	void DevelopDP(double,double);	// Differentiation probability
	void MutateDP();
};

// Init
void DP::InitDP()
{
	T		= 0;
	Gt		= 0;
	pGt		= 0;
	P1		= 0;
	P2		= 0;
	P3		= 0;
	P4		= 0;
}

void DP::DevelopDP(double input1, double input2)
{
	double P_T;
	P_T = P1 + (P2-P1)/(1+exp(P4*20*(input1 - P3)));
	ru() < P_T? T = 1 : T = 0;
}

void DP::MutateDP()
{
	bool Mut = 0;
	// P1: Minimal differentiation probability 
	double T_P1 = P1;
	if(ru() < u_rate){mu(P1);}
	constraint(P1,0,1);
	if(T_P1 != P1) {Mut = 1;}
	// P2: Maximum differentiation probability
	double T_P2 = P2;
	if(ru() < u_rate){mu(P2);}
	constraint(P2,0,1);
	if(T_P2 != P2) {Mut = 1;}
	// P3: Inflection point
	double T_P3 = P3;
	if(ru() < u_rate){mu(P3); Mut = 1;}
	// P4: Steepness
	double T_P4 = P4;
	if(ru() < u_rate){mu(P4); Mut = 1;}
	
	// ADMINISTRATION; keep track of genotype number
	if(Mut)
	{
		pGt = Gt;
		Gt  = Gcount + 1;
		Gcount += 1;
	}
	return;
}
#endif
